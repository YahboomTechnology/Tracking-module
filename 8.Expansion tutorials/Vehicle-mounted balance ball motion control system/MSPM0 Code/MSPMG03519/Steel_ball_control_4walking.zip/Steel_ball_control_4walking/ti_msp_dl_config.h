/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G351X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G351X
#define CONFIG_MSPM0G3519

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_Servo */
#define PWM_Servo_INST                                                     TIMA0
#define PWM_Servo_INST_IRQHandler                               TIMA0_IRQHandler
#define PWM_Servo_INST_INT_IRQN                                 (TIMA0_INT_IRQn)
#define PWM_Servo_INST_CLK_FREQ                                            40000
/* GPIO defines for channel 0 */
#define GPIO_PWM_Servo_C0_PORT                                             GPIOB
#define GPIO_PWM_Servo_C0_PIN                                      DL_GPIO_PIN_8
#define GPIO_PWM_Servo_C0_IOMUX                                  (IOMUX_PINCM25)
#define GPIO_PWM_Servo_C0_IOMUX_FUNC                 IOMUX_PINCM25_PF_TIMA0_CCP0
#define GPIO_PWM_Servo_C0_IDX                                DL_TIMER_CC_0_INDEX



/* Defines for TIMER_0 */
#define TIMER_0_INST                                                     (TIMG0)
#define TIMER_0_INST_IRQHandler                                 TIMG0_IRQHandler
#define TIMER_0_INST_INT_IRQN                                   (TIMG0_INT_IRQn)
#define TIMER_0_INST_LOAD_VALUE                                          (3999U)




/* Defines for motor */
#define motor_INST                                                          I2C1
#define motor_INST_IRQHandler                                    I2C1_IRQHandler
#define motor_INST_INT_IRQN                                        I2C1_INT_IRQn
#define motor_BUS_SPEED_HZ                                                400000
#define GPIO_motor_SDA_PORT                                                GPIOA
#define GPIO_motor_SDA_PIN                                        DL_GPIO_PIN_16
#define GPIO_motor_IOMUX_SDA                                     (IOMUX_PINCM38)
#define GPIO_motor_IOMUX_SDA_FUNC                      IOMUX_PINCM38_PF_I2C1_SDA
#define GPIO_motor_SCL_PORT                                                GPIOA
#define GPIO_motor_SCL_PIN                                        DL_GPIO_PIN_15
#define GPIO_motor_IOMUX_SCL                                     (IOMUX_PINCM37)
#define GPIO_motor_IOMUX_SCL_FUNC                      IOMUX_PINCM37_PF_I2C1_SCL

/* Defines for OLED_I2C */
#define OLED_I2C_INST                                                       I2C0
#define OLED_I2C_INST_IRQHandler                                 I2C0_IRQHandler
#define OLED_I2C_INST_INT_IRQN                                     I2C0_INT_IRQn
#define OLED_I2C_BUS_SPEED_HZ                                             400000
#define GPIO_OLED_I2C_SDA_PORT                                             GPIOA
#define GPIO_OLED_I2C_SDA_PIN                                     DL_GPIO_PIN_28
#define GPIO_OLED_I2C_IOMUX_SDA                                   (IOMUX_PINCM3)
#define GPIO_OLED_I2C_IOMUX_SDA_FUNC                    IOMUX_PINCM3_PF_I2C0_SDA
#define GPIO_OLED_I2C_SCL_PORT                                             GPIOA
#define GPIO_OLED_I2C_SCL_PIN                                     DL_GPIO_PIN_31
#define GPIO_OLED_I2C_IOMUX_SCL                                   (IOMUX_PINCM6)
#define GPIO_OLED_I2C_IOMUX_SCL_FUNC                    IOMUX_PINCM6_PF_I2C0_SCL


/* Defines for UART_0 */
#define UART_0_INST                                                        UART0
#define UART_0_INST_FREQUENCY                                            4000000
#define UART_0_INST_IRQHandler                                  UART0_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART0_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOA
#define GPIO_UART_0_TX_PORT                                                GPIOA
#define GPIO_UART_0_RX_PIN                                        DL_GPIO_PIN_11
#define GPIO_UART_0_TX_PIN                                        DL_GPIO_PIN_10
#define GPIO_UART_0_IOMUX_RX                                     (IOMUX_PINCM22)
#define GPIO_UART_0_IOMUX_TX                                     (IOMUX_PINCM21)
#define GPIO_UART_0_IOMUX_RX_FUNC                      IOMUX_PINCM22_PF_UART0_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                      IOMUX_PINCM21_PF_UART0_TX
#define UART_0_BAUD_RATE                                                (115200)
#define UART_0_IBRD_4_MHZ_115200_BAUD                                        (2)
#define UART_0_FBRD_4_MHZ_115200_BAUD                                       (11)
/* Defines for UART_K230 */
#define UART_K230_INST                                                     UART1
#define UART_K230_INST_FREQUENCY                                         4000000
#define UART_K230_INST_IRQHandler                               UART1_IRQHandler
#define UART_K230_INST_INT_IRQN                                   UART1_INT_IRQn
#define GPIO_UART_K230_RX_PORT                                             GPIOB
#define GPIO_UART_K230_TX_PORT                                             GPIOB
#define GPIO_UART_K230_RX_PIN                                      DL_GPIO_PIN_7
#define GPIO_UART_K230_TX_PIN                                      DL_GPIO_PIN_6
#define GPIO_UART_K230_IOMUX_RX                                  (IOMUX_PINCM24)
#define GPIO_UART_K230_IOMUX_TX                                  (IOMUX_PINCM23)
#define GPIO_UART_K230_IOMUX_RX_FUNC                   IOMUX_PINCM24_PF_UART1_RX
#define GPIO_UART_K230_IOMUX_TX_FUNC                   IOMUX_PINCM23_PF_UART1_TX
#define UART_K230_BAUD_RATE                                             (115200)
#define UART_K230_IBRD_4_MHZ_115200_BAUD                                     (2)
#define UART_K230_FBRD_4_MHZ_115200_BAUD                                    (11)





/* Port definition for Pin Group LED */
#define LED_PORT                                                         (GPIOB)

/* Defines for D1: GPIOB.2 with pinCMx 15 on package pin 14 */
#define LED_D1_PIN                                               (DL_GPIO_PIN_2)
#define LED_D1_IOMUX                                             (IOMUX_PINCM15)
/* Defines for D2: GPIOB.3 with pinCMx 16 on package pin 15 */
#define LED_D2_PIN                                               (DL_GPIO_PIN_3)
#define LED_D2_IOMUX                                             (IOMUX_PINCM16)
/* Port definition for Pin Group KEY */
#define KEY_PORT                                                         (GPIOA)

/* Defines for K1: GPIOA.2 with pinCMx 7 on package pin 8 */
#define KEY_K1_PIN                                               (DL_GPIO_PIN_2)
#define KEY_K1_IOMUX                                              (IOMUX_PINCM7)
/* Defines for K4: GPIOA.23 with pinCMx 53 on package pin 43 */
#define KEY_K4_PIN                                              (DL_GPIO_PIN_23)
#define KEY_K4_IOMUX                                             (IOMUX_PINCM53)
/* Port definition for Pin Group Sensor_four */
#define Sensor_four_PORT                                                 (GPIOA)

/* Defines for X1: GPIOA.25 with pinCMx 55 on package pin 45 */
#define Sensor_four_X1_PIN                                      (DL_GPIO_PIN_25)
#define Sensor_four_X1_IOMUX                                     (IOMUX_PINCM55)
/* Defines for X2: GPIOA.24 with pinCMx 54 on package pin 44 */
#define Sensor_four_X2_PIN                                      (DL_GPIO_PIN_24)
#define Sensor_four_X2_IOMUX                                     (IOMUX_PINCM54)
/* Defines for X3: GPIOA.26 with pinCMx 59 on package pin 46 */
#define Sensor_four_X3_PIN                                      (DL_GPIO_PIN_26)
#define Sensor_four_X3_IOMUX                                     (IOMUX_PINCM59)
/* Defines for X4: GPIOA.27 with pinCMx 60 on package pin 47 */
#define Sensor_four_X4_PIN                                      (DL_GPIO_PIN_27)
#define Sensor_four_X4_IOMUX                                     (IOMUX_PINCM60)



/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_Servo_init(void);
void SYSCFG_DL_TIMER_0_init(void);
void SYSCFG_DL_motor_init(void);
void SYSCFG_DL_OLED_I2C_init(void);
void SYSCFG_DL_UART_0_init(void);
void SYSCFG_DL_UART_K230_init(void);

void SYSCFG_DL_SYSTICK_init(void);

bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
