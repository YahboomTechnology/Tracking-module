/* Four_linewalking_debug.c - ��·ѭ���������԰� */
/*
 * �� Four_linewalking.c ������
 *   1. ����ֻʹ����·����̽ͷѭ����
 *   2. Debug_LineWalking_Run() ����������
 *   3. �� STANDALONE_LINEWALKING_ENABLE ѡ���Ƿ����á�
 *
 * Debug_LineWalking_WithBall() ʹ��ͬһ��ѭ�����򣬲�����
 * ������Բ�����
 */
#include "Four_linewalking_debug.h"
#include "Four_linewalking.h"
#include "app_k230.h"
#include "timer.h"
#include "app_kalman.h"
#include <stdio.h>

/* ============ �������԰���� ============ */
/* �������ڡ������ٶȺ͵��⻷ PID ������ */
#define DEBUG_LINE_PERIOD_MS           20U
#define DEBUG_LINE_BASE_SPEED          200.0f
#define DEBUG_LINE_KP                  55.0f
#define DEBUG_LINE_KI                  0.00f
#define DEBUG_LINE_KD                  645.0f
#define DEBUG_LINE_OUT_MAX             450.0f
#define DEBUG_LINE_INTEGRAL_MAX        150.0f
#define DEBUG_LINE_MAX_MOTOR_CMD       1000.0f
#define DEBUG_LINE_MIN_MOTOR_CMD       0.0f
#define DEBUG_LINE_PRINT_PERIOD_MS     100U

#define BALL_INERTIA_FWD      -0.60f
#define BALL_INERTIA_TURN     0.20f
#define BALL_INERTIA_PID_MAX  5000.0f
/* �𲽲�����ǰ 2s ���������ͺ�ʱǰ�ƣ�ͣ����������ͣ��ǰ��ʱ������ */
#define BALL_START_COMP    5.0f
#define BALL_STOP_COMP     -5.0f
#define BALL_START_COMP_TIME_MS 3000

/* 0 ʹ��ԭʼ PID��1 �����������˲��� */
#define DEBUG_LINE_USE_KALMAN          0
#define DEBUG_LINE_KALMAN_Q            0.02f
#define DEBUG_LINE_KALMAN_R            0.80f

/* ���ߴ������ȷ��������𽥼�ǿ�һ����ȣ���ʱͣ���� */
#define DEBUG_LINE_LOST_DEBOUNCE_MS    60U
#define DEBUG_LINE_LOST_TURN_SOFT      100.0f
#define DEBUG_LINE_LOST_TURN_HARD      180.0f
#define DEBUG_LINE_LOST_ESCALATE_MS    400U
#define DEBUG_LINE_LOST_STOP_MS        2000U

/* PID �����ڱ�����״̬�� */
static float     s_debug_last_direction = 0.0f;   /* ���һ����Ч���� */
static float     s_debug_last_turn_dir = 0.0f;    /* ���һ����Чת���� */
static uint32_t  s_debug_lost_start_ms = 0U;      /* ������ʼʱ�� */
static uint8_t   s_debug_line_lost = 0U;          /* 1 ��ʾ��ǰ��·ȫ�׶��� */
static float     s_debug_err_last = 0.0f;
static float     s_debug_state_error = 0.0f;
static float     s_debug_integral = 0.0f;
static uint32_t  s_debug_last_run_ms = 0U;
static uint32_t  s_debug_last_print_ms = 0U;
static uint32_t  s_debug_last_task_start_ms = 0U;
static uint8_t   s_debug_inited = 0U;

#if DEBUG_LINE_USE_KALMAN
static Kalman_t s_debug_line_kalman;
#endif

static float Debug_Clamp(float value, float min, float max)
{
    if (value < min)
    {
        return min;
    }
    if (value > max)
    {
        return max;
    }
    return value;
}

/* ÿ����������ʱ��λ PID ״̬��������һ�����ͻ��ִ��뱾�Ρ� */
static void Debug_Line_Reset(void)
{
    s_debug_err_last = 0.0f;
    s_debug_state_error = 0.0f;
    s_debug_integral = 0.0f;
    s_debug_last_direction = 0.0f;
    s_debug_last_turn_dir = 0.0f;
    s_debug_lost_start_ms = 0U;
    s_debug_line_lost = 0U;
    s_debug_last_run_ms = Get_Time();
    s_debug_last_print_ms = Get_Time();

#if DEBUG_LINE_USE_KALMAN
    Kalman_Init(&s_debug_line_kalman,
                DEBUG_LINE_KALMAN_Q,
                DEBUG_LINE_KALMAN_R);
#endif
}

/* ��ȡ��·���������ϳ�����ƫ� */
static float Debug_Line_GetError(void)
{
    uint32_t port_state = DL_GPIO_readPins(Sensor_four_PORT,
        Sensor_four_X1_PIN | Sensor_four_X2_PIN |
        Sensor_four_X3_PIN | Sensor_four_X4_PIN);

    int x1 = (port_state & Sensor_four_X1_PIN) ? 1 : 0;
    int x2 = (port_state & Sensor_four_X2_PIN) ? 1 : 0;
    int x3 = (port_state & Sensor_four_X3_PIN) ? 1 : 0;
    int x4 = (port_state & Sensor_four_X4_PIN) ? 1 : 0;

    /* ȫ�ױ�ʾ���ߣ�������һ����Чƫ� */
    if ((x1 == x2) && (x2 == x3) && (x3 == x4))
    {
        s_debug_line_lost = 1U;
        return s_debug_state_error;
    }
    s_debug_line_lost = 0U;

    /* L2(x1)=+2, L1(x2)=+1, R1(x3)=-1, R2(x4)=-2�� */
    s_debug_state_error = 1.5f * x1 + 1.0f * x2 - 1.0f * x3 - 1.5f * x4;

    if (s_debug_state_error > 0.0f)
    {
        s_debug_last_direction = 1.0f;
    }
    else if (s_debug_state_error < 0.0f)
    {
        s_debug_last_direction = -1.0f;
    }
    return s_debug_state_error;
}

/* λ��ʽ PID��P + I + D�����ֺ���������޷��� */
static float Debug_Line_PID(float error)
{
    float p_term = DEBUG_LINE_KP * error;
    float d_term = DEBUG_LINE_KD * (error - s_debug_err_last);
    float output;

    s_debug_integral += error;
    s_debug_integral = Debug_Clamp(s_debug_integral,
                                   -DEBUG_LINE_INTEGRAL_MAX,
                                    DEBUG_LINE_INTEGRAL_MAX);

    output = p_term + DEBUG_LINE_KI * s_debug_integral + d_term;
    output = Debug_Clamp(output, -DEBUG_LINE_OUT_MAX, DEBUG_LINE_OUT_MAX);

    s_debug_err_last = error;
    return output;
}

/* ������·ѭ�������� */
void Debug_LineWalking_Run(void)
{
    extern volatile uint32_t g_task_start_ms;
    uint32_t now = Get_Time();

    if ((s_debug_inited == 0U) || (g_task_start_ms != s_debug_last_task_start_ms))
    {
        s_debug_last_task_start_ms = g_task_start_ms;
        Debug_Line_Reset();
        s_debug_inited = 1U;
    }

    if ((now - s_debug_last_run_ms) < DEBUG_LINE_PERIOD_MS)
    {
        return;
    }
    s_debug_last_run_ms = now;

    float raw_error = Debug_Line_GetError();
    float line_error = raw_error;
    float turn_cmd = 0.0f;

    if (s_debug_line_lost != 0U)
    {
        if (s_debug_lost_start_ms == 0U)
        {
            s_debug_lost_start_ms = now;
        }
        uint32_t lost_ms = now - s_debug_lost_start_ms;

        if (lost_ms >= DEBUG_LINE_LOST_STOP_MS)
        {
            control_speed(0, 0, 0, 0);
            return;
        }

        if (lost_ms >= DEBUG_LINE_LOST_DEBOUNCE_MS)
        {
            float lost_turn = (lost_ms >= DEBUG_LINE_LOST_ESCALATE_MS)
                              ? DEBUG_LINE_LOST_TURN_HARD
                              : DEBUG_LINE_LOST_TURN_SOFT;
            float lost_dir = 0.0f;
            if (s_debug_last_direction > 0.0f)      { lost_dir = 1.0f; }
            else if (s_debug_last_direction < 0.0f) { lost_dir = -1.0f; }
            else if (s_debug_last_turn_dir > 0.0f)  { lost_dir = 1.0f; }
            else if (s_debug_last_turn_dir < 0.0f)  { lost_dir = -1.0f; }
            else                                    { lost_dir = 1.0f; }
            turn_cmd = lost_dir * lost_turn;
            s_debug_err_last = raw_error;
        }
        else
        {
            turn_cmd = Debug_Line_PID(raw_error);
        }
    }
    else
    {
        s_debug_lost_start_ms = 0U;

#if DEBUG_LINE_USE_KALMAN
        line_error = Kalman_Filter(&s_debug_line_kalman, raw_error);
#endif

        turn_cmd = Debug_Line_PID(line_error);

        if (turn_cmd > 1.0f)      { s_debug_last_turn_dir = 1.0f; }
        else if (turn_cmd < -1.0f){ s_debug_last_turn_dir = -1.0f; }
    }

    /* �ѵ�ǰ���԰�ת�������㵽 5000 ���̣���������Բ���ʹ�á� */
    pid_output_IRR = (int)(turn_cmd * (BALL_INERTIA_PID_MAX / DEBUG_LINE_OUT_MAX));

    float base_speed = (float)g_line_speed;

    if (base_speed <= 0.0f)
    {
        base_speed = DEBUG_LINE_BASE_SPEED;
    }

    float right_cmd = base_speed + turn_cmd;
    float left_cmd  = base_speed - turn_cmd;

    right_cmd = Debug_Clamp(right_cmd,
                            DEBUG_LINE_MIN_MOTOR_CMD,
                            DEBUG_LINE_MAX_MOTOR_CMD);
    left_cmd = Debug_Clamp(left_cmd,
                           DEBUG_LINE_MIN_MOTOR_CMD,
                           DEBUG_LINE_MAX_MOTOR_CMD);

    control_speed(0, (int16_t)right_cmd, 0, (int16_t)left_cmd);

    if ((now - s_debug_last_print_ms) >= DEBUG_LINE_PRINT_PERIOD_MS)
    {
        uint32_t ps = DL_GPIO_readPins(Sensor_four_PORT,
            Sensor_four_X1_PIN | Sensor_four_X2_PIN |
            Sensor_four_X3_PIN | Sensor_four_X4_PIN);
        int s1 = (ps & Sensor_four_X1_PIN) ? 1 : 0;
        int s2 = (ps & Sensor_four_X2_PIN) ? 1 : 0;
        int s3 = (ps & Sensor_four_X3_PIN) ? 1 : 0;
        int s4 = (ps & Sensor_four_X4_PIN) ? 1 : 0;

        printf("IR=%d%d%d%d E=%.2f T=%.2f L=%d R=%d LOST=%d\r\n",
               s1, s2, s3, s4,
               (double)line_error,
               (double)turn_cmd,
               (int)left_cmd,
               (int)right_cmd,
               (int)s_debug_line_lost);

        s_debug_last_print_ms = now;
    }
}

/* ��·ѭ�� + ������Բ����� */
void Debug_LineWalking_WithBall(float ball_target_cm)
{
    static uint32_t last_task_start_ms = 0xFFFFFFFFU;
    static uint8_t  ramp_ready = 0;
    static uint8_t  stop_ready = 0;
    static uint32_t stop_start_ms = 0;
    static int      saved_spd = 0;
    static int      stop_spd = 0;
    extern volatile uint32_t g_task_start_ms;
    float start_comp = 0.0f;
    float stop_comp  = 0.0f;

    /* �������¿�ʼʱ��¼Ѳ���ٶȣ�����λ������/��ͣ��״̬�� */
    if (g_task_start_ms != last_task_start_ms)
    {
        last_task_start_ms = g_task_start_ms;
        saved_spd = g_line_speed;
        ramp_ready = 1;
        stop_ready = 0;
        stop_start_ms = 0;
        stop_spd = 0;
    }

    /* ͣ���׶Σ��ӵ�ǰ�ٶȰ� BALL_STOP_TIME_MS ���Լ��ٵ� 0�� */
    if (g_slow_stop)
    {
        if (!stop_ready)
        {
            stop_start_ms = Get_Time();
            stop_spd = g_line_speed;
            stop_ready = 1;
        }

        uint32_t st = Get_Time() - stop_start_ms;
        if (st >= BALL_STOP_TIME_MS)
        {
            g_line_speed = 0;
            control_pwm(0, 0, 0, 0);
            K230_Receive_Process();
            K230_Servo_Control(ball_target_cm);
            return;
        }

        float stop_ratio = 1.0f - (float)st / (float)BALL_STOP_TIME_MS;
        if (stop_ratio < 0.0f) stop_ratio = 0.0f;
        if (stop_ratio > 1.0f) stop_ratio = 1.0f;
        stop_comp = BALL_STOP_COMP * stop_ratio;
        g_line_speed = (int)((float)stop_spd * stop_ratio);
    }
    else
    {
        stop_ready = 0;
        stop_start_ms = 0;
        stop_spd = 0;

        /* �𲽽׶Σ�������ٶ����Լ��ٵ�Ѳ���ٶȡ� */
        if (ramp_ready)
        {
            uint32_t et = Get_Time() - last_task_start_ms;
            if (et < BALL_START_COMP_TIME_MS)
                start_comp = BALL_START_COMP * (1.0f - (float)et / (float)BALL_START_COMP_TIME_MS);
            if (et < BALL_RAMP_TIME_MS)
            {
                float ramp = (float)et / (float)BALL_RAMP_TIME_MS;
                if (ramp < BALL_RAMP_MIN_RATIO) ramp = BALL_RAMP_MIN_RATIO;
                if (ramp > 1.0f) ramp = 1.0f;
                g_line_speed = (int)((float)saved_spd * ramp);
            }
            else
            {
                g_line_speed = saved_spd;
            }
        }
    }

    /* ��Ѳ�ߣ��ٽ��� K230 �����Ͳ�����Ķ��Ŀ�ꡣ */
    Debug_LineWalking_Run();
    K230_Receive_Process();

    float compensated = ball_target_cm;
    compensated -= BALL_INERTIA_FWD;
    if (pid_output_IRR > 0)
        compensated -= BALL_INERTIA_TURN * (float)pid_output_IRR / BALL_INERTIA_PID_MAX;
    else if (pid_output_IRR < 0)
        compensated += BALL_INERTIA_TURN * (float)(-pid_output_IRR) / BALL_INERTIA_PID_MAX;
    compensated += start_comp + stop_comp;

    K230_Servo_Control(compensated);
}
