#include "bsp_motor_iic.h"
#include "delay.h"

int Encoder_Offset[4];
int Encoder_Now[4];

void float_to_bytes(float f, uint8_t *bytes)
{
    memcpy(bytes, &f, sizeof(float));
}

float char2float(char *p)
{
    float *p_Int;
    p_Int = (float *)malloc(sizeof(float));
    memcpy(p_Int, p, sizeof(float));
    float x = *p_Int;
    free(p_Int);
    return x;
}

static void Motor_I2C_WaitIdle(void)
{
    uint32_t timeout = 1000000U;
    while (!(DL_I2C_getControllerStatus(motor_INST) & DL_I2C_CONTROLLER_STATUS_IDLE) && (timeout--))
    {
    }
}

static void Motor_I2C_WaitBusy(void)
{
    uint32_t timeout = 1000000U;
    while ((DL_I2C_getControllerStatus(motor_INST) & DL_I2C_CONTROLLER_STATUS_BUSY_BUS) && (timeout--))
    {
    }
    Motor_I2C_WaitIdle();
}

/* I2C д�Ĵ�����
 * ����֡��ʽ���Ĵ�����ַ + �����ֽ�
 * addr=0x26 ����·����������ַ
 */
static int Motor_I2C_Write(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *data)
{
    uint8_t tx[9];
    uint16_t txLen = (uint16_t)len + 1U;
    uint16_t sent = 0U;
    uint16_t i = 0U;
    uint32_t fillTimeout = 1000000U;

    tx[0] = reg;
    for (i = 0U; i < len; i++)
    {
        tx[i + 1U] = data[i];
    }

    Motor_I2C_WaitIdle();
    DL_I2C_flushControllerTXFIFO(motor_INST);
    sent = DL_I2C_fillControllerTXFIFO(motor_INST, tx, txLen);
    DL_I2C_startControllerTransfer(motor_INST, addr, DL_I2C_CONTROLLER_DIRECTION_TX, txLen);

    while ((sent < txLen) && (fillTimeout--) &&
           !(DL_I2C_getControllerStatus(motor_INST) & DL_I2C_CONTROLLER_STATUS_ERROR))
    {
        if (!DL_I2C_isControllerTXFIFOFull(motor_INST))
        {
            sent += DL_I2C_fillControllerTXFIFO(motor_INST, &tx[sent], txLen - sent);
        }
    }

    Motor_I2C_WaitBusy();
    return (DL_I2C_getControllerStatus(motor_INST) & DL_I2C_CONTROLLER_STATUS_ERROR) ? 1 : 0;
}

/* I2C ���Ĵ�����
 * ��һ�η��ͼĴ�����ַ���ڶ��ζ�ȡָ����������
 */
static int Motor_I2C_Read(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *buf)
{
    uint8_t i = 0U;

    Motor_I2C_WaitIdle();
    DL_I2C_flushControllerTXFIFO(motor_INST);
    DL_I2C_fillControllerTXFIFO(motor_INST, &reg, 1U);
    DL_I2C_startControllerTransfer(motor_INST, addr, DL_I2C_CONTROLLER_DIRECTION_TX, 1U);
    Motor_I2C_WaitBusy();

    Motor_I2C_WaitIdle();
    DL_I2C_startControllerTransfer(motor_INST, addr, DL_I2C_CONTROLLER_DIRECTION_RX, len);
    Motor_I2C_WaitBusy();

    for (i = 0U; i < len; i++)
    {
        buf[i] = DL_I2C_receiveControllerData(motor_INST);
    }

    return 0;
}

/* ����Ϊ��·������������ú�����ȫ��ͨ��Ӳ�� I2C1 ���� */
void Set_motor_type(uint8_t data)
{
    Motor_I2C_Write(Motor_model_ADDR, MOTOR_TYPE_REG, 1, &data);
}

void Set_motor_deadzone(uint16_t data)
{
    static uint8_t buf_tempzone[2];
    buf_tempzone[0] = (data >> 8) & 0xff;
    buf_tempzone[1] = data;
    Motor_I2C_Write(Motor_model_ADDR, MOTOR_DeadZONE_REG, 2, buf_tempzone);
}

void Set_Pluse_line(uint16_t data)
{
    static uint8_t buf_templine[2];
    buf_templine[0] = (data >> 8) & 0xff;
    buf_templine[1] = data;
    Motor_I2C_Write(Motor_model_ADDR, MOTOR_PluseLine_REG, 2, buf_templine);
}

void Set_Pluse_Phase(uint16_t data)
{
    static uint8_t buf_tempPhase[2];
    buf_tempPhase[0] = (data >> 8) & 0xff;
    buf_tempPhase[1] = data;
    Motor_I2C_Write(Motor_model_ADDR, MOTOR_PlusePhase_REG, 2, buf_tempPhase);
}

void Set_Wheel_dis(float data)
{
    static uint8_t bytes[4];
    float_to_bytes(data, bytes);
    Motor_I2C_Write(Motor_model_ADDR, WHEEL_DIA_REG, 4, bytes);
}

/* �ٶȿ��ƣ�
 * ÿ·�ٶ�ռ�����ֽڣ����ֽ���ǰ�����ֽ��ں�
 */
void control_speed(int16_t m1, int16_t m2, int16_t m3, int16_t m4)
{
    static uint8_t speed[8];
    speed[0] = (m1 >> 8) & 0xff;
    speed[1] = m1;
    speed[2] = (m2 >> 8) & 0xff;
    speed[3] = m2;
    speed[4] = (m3 >> 8) & 0xff;
    speed[5] = m3;
    speed[6] = (m4 >> 8) & 0xff;
    speed[7] = m4;
    Motor_I2C_Write(Motor_model_ADDR, SPEED_Control_REG, 8, speed);
}

/* PWM ֱ�ӿ��ƣ�
 * ����Ϊ PWM ռ�ձ�ֵ��ͣ��ʱӦ���� control_pwm(0,0,0,0)
 */
void control_pwm(int16_t m1, int16_t m2, int16_t m3, int16_t m4)
{
    static uint8_t pwm[8];
    pwm[0] = (m1 >> 8) & 0xff;
    pwm[1] = m1;
    pwm[2] = (m2 >> 8) & 0xff;
    pwm[3] = m2;
    pwm[4] = (m3 >> 8) & 0xff;
    pwm[5] = m3;
    pwm[6] = (m4 >> 8) & 0xff;
    pwm[7] = m4;
    Motor_I2C_Write(Motor_model_ADDR, PWM_Control_REG, 8, pwm);
}

/* ��ȡ��· 10ms ʵʱ������ֵ�����ڶ������ٶȹ��� */
void Read_10_Enconder(void)
{
    static uint8_t buf[8];

    /* 0x10~0x13 ���������·��������һ�ζ�ȡ 8 �ֽڣ������Ĵ� I2C ���� */
    Motor_I2C_Read(Motor_model_ADDR, READ_TEN_M1Enconer_REG, 8, buf);
    Encoder_Offset[0] = (buf[0] << 8) | buf[1];
    Encoder_Offset[1] = (buf[2] << 8) | buf[3];
    Encoder_Offset[2] = (buf[4] << 8) | buf[5];
    Encoder_Offset[3] = (buf[6] << 8) | buf[7];
}
/* ��ȡ��·�ۼƱ�����ֵ���ɸ� 16 λ�͵� 16 λƴ�� 32 λ */
void Read_ALL_Enconder(void)
{
    static uint8_t buf[2];
    static uint8_t buf2[2];

    Motor_I2C_Read(Motor_model_ADDR, READ_ALLHigh_M1_REG, 2, buf);
    Motor_I2C_Read(Motor_model_ADDR, READ_ALLLOW_M1_REG, 2, buf2);
    Encoder_Now[0] = buf[0] << 24 | buf[1] << 16 | buf2[0] << 8 | buf2[1];

    Motor_I2C_Read(Motor_model_ADDR, READ_ALLHigh_M2_REG, 2, buf);
    Motor_I2C_Read(Motor_model_ADDR, READ_ALLLOW_M2_REG, 2, buf2);
    Encoder_Now[1] = buf[0] << 24 | buf[1] << 16 | buf2[0] << 8 | buf2[1];

    Motor_I2C_Read(Motor_model_ADDR, READ_ALLHigh_M3_REG, 2, buf);
    Motor_I2C_Read(Motor_model_ADDR, READ_ALLLOW_M3_REG, 2, buf2);
    Encoder_Now[2] = buf[0] << 24 | buf[1] << 16 | buf2[0] << 8 | buf2[1];

    Motor_I2C_Read(Motor_model_ADDR, READ_ALLHigh_M4_REG, 2, buf);
    Motor_I2C_Read(Motor_model_ADDR, READ_ALLLOW_M4_REG, 2, buf2);
    Encoder_Now[3] = buf[0] << 24 | buf[1] << 16 | buf2[0] << 8 | buf2[1];
}
