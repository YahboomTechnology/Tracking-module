#include "board.h"
#include "stdio.h"

char buf[50] = {'\0'};

int main(void)
{
	unsigned int LineL1 = 1, LineL2 = 1, LineR1 = 1, LineR2 = 1;//��·Ѳ��ģ���ʼֵ Initial value of four-way line patrol module
	board_init();//��س�ʼ�� Related initialization
	sprintf(buf,"Four_way patrol line\n");//��·Ѳ��ģ�� Four-way line patrol module
	uart0_send_string(buf);//���ڷ��ͺ��� Serial port sending function
    while (1) 
    {                      
			LineL1 = DL_GPIO_readPins(LineWalk_L1_PORT, LineWalk_L1_PIN_27_PIN) > 0 ? 1 : 0;//��ȡ��һ Read left one
			LineL2 = DL_GPIO_readPins(LineWalk_L2_PORT, LineWalk_L2_PIN_26_PIN) > 0 ? 1 : 0;//��ȡ��� Read left second
			LineR1 = DL_GPIO_readPins(LineWalk_R1_PORT, LineWalk_R1_PIN_24_PIN) > 0 ? 1 : 0;//��ȡ��һ Read right one
			LineR2 = DL_GPIO_readPins(LineWalk_R2_PORT, LineWalk_R2_PIN_25_PIN) > 0 ? 1 : 0;//��ȡ�Ҷ�	Read right second	 
			sprintf(buf,"LineL1 = %d,LineL2 = %d,LineR1 = %d,LineR2 = %d\n",LineL1,LineL2,LineR1,LineR2);		
			uart0_send_string(buf);//���ڷ��ͺ��� Serial port sending function
			delay_ms(300);
		}
}
