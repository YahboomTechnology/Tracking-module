#include "Line_Walking.h"

//四路巡线模块引脚初始化
void Line_Walking_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* GPIOA Periph clock enable */
	/* 使能 DPIOA 时钟 */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	/* Configure PA1 - PA4 in GPIO_Mode_IPU mode */
	//四路循线模块对应 X1:PA1	X2:PA2	X3:PA3	X4:PA4
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

/*
说明：
			本例程只提供简单的模块测试功能，可以通过该例程调节循迹模块的灵敏度
			并未涉及四路循迹模块多种情况判断。

			若想驱动小车：可结合自己的电机驱动代码文件
			对循迹模块的各个检测状态进行判断，根据判断加入电机驱动控制
*/

void Line_Walking_State(void)//四路循迹模块 检测状态
{
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == Bit_SET)
	{
		printf("X1\n");
	}
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == Bit_SET)
	{
		printf("X2\n");
	}
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == Bit_SET)
	{
		printf("X3\n");
	}
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == Bit_SET)
	{
		printf("X4\n");
	}
}
