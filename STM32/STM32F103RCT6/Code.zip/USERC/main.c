#include "stm32f10x.h"
#include "UART.h"
#include "SysTick.h"
#include "Line_Walking.h"

int main(void)
{

    SysTick_Init();//滴答定时器初始化
    UART1_Init();//UART1初始化
		Line_Walking_GPIO_Init();//四路巡线模块初始化
		printf("Line_Walking_State!\n");
	
    while(1)
    {
			Line_Walking_State();//四路巡线输出状态
			Delay_us(1000000);
    }
}
