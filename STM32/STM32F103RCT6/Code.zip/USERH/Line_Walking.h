#ifndef __LINE_WALKING_H__
#define __LINE_WALKING_H__

#include "stm32f10x.h"
#include "UART.h"

void Line_Walking_GPIO_Init(void);//四路巡线模块引脚初始化
void Line_Walking_State(void);//四路循迹模块模块对应检测状态

#endif
